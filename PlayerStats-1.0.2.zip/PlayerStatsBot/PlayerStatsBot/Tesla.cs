namespace PlayerStatsBot
{
	public class Tesla
	{
		public int Fires;
		public int Kills;
		public int ScpKills;
		public int Dboikills;
		public int NerdKills;
		public int CiKills;
		public int NtfKills;
	}
}