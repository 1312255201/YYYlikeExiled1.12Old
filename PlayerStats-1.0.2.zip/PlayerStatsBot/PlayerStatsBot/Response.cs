using System.Collections.Generic;

namespace PlayerStatsBot
{
	public class Response
	{
		public List<SteamUser> players { get; set; }
	}
}