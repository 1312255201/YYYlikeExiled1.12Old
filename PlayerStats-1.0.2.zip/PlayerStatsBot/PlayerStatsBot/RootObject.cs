namespace PlayerStatsBot
{
	public class RootObject
	{
		public Response response { get; set; }
	}
}