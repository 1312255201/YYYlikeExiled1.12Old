namespace PlayerStatsBot
{
	public class Sync
	{
		public ulong DiscordId { get; set; }

		public string SteamId { get; set; }
	}
}